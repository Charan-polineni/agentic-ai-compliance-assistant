"""Review a vendor intake against a small, fictional company policy."""
import argparse
import json
from pathlib import Path

DEFAULT_CASE = Path(__file__).with_name("sample_vendor.json")
CONTROLS = {
    "security_review_complete": "Obtain a completed security review.",
    "data_processing_agreement_signed": "Obtain a signed data processing agreement.",
    "retention_schedule_documented": "Document the data retention schedule.",
}


def review(case):
    if not isinstance(case, dict):
        raise ValueError("The case must be a JSON object.")
    vendor = case.get("vendor")
    if not isinstance(vendor, str) or not vendor.strip():
        raise ValueError("Provide a non-empty vendor name.")
    processes_data = case.get("processes_personal_data")
    if type(processes_data) is not bool:
        raise ValueError("processes_personal_data must be true or false.")
    evidence = case.get("evidence", {})
    if not isinstance(evidence, dict):
        raise ValueError("evidence must be a JSON object.")

    plan = list(CONTROLS) if processes_data else ["security_review_complete"]
    findings = []
    for control in plan:
        observed = evidence.get(control)
        if observed is not None and type(observed) is not bool:
            raise ValueError(f"{control} must be true, false, or null.")
        status = {True: "met", False: "not_met", None: "missing"}[observed]
        findings.append({
            "control": control,
            "evidence": observed,
            "status": status,
            "follow_up": None if observed is True else CONTROLS[control],
        })

    needs_follow_up = any(item["status"] != "met" for item in findings)
    return {
        "vendor": vendor.strip(),
        "review_status": "follow_up_required" if needs_follow_up else "ready_for_human_review",
        "findings": findings,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", nargs="?", type=Path, default=DEFAULT_CASE)
    args = parser.parse_args()
    try:
        case = json.loads(args.case.read_text(encoding="utf-8-sig"))
        report = review(case)
    except (OSError, ValueError) as error:
        parser.exit(2, f"error: {error}\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
